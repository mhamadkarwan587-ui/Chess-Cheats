package com.chesshelper.overlay.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Keeps the full game state by matching each new screen reading to a legal move. */
public final class GameTracker {
    public Position pos;
    public final List<String> keys = new ArrayList<>();
    public boolean synced;          // false = joined mid-game, castling rights were guessed
    public boolean myWhite;

    private static final char[] START_BOARD = Position.fromFen(Rules.START_FEN).b;

    public GameTracker(boolean myWhite) {
        this.myWhite = myWhite;
        reset();
    }

    public void reset() {
        pos = Position.fromFen(Rules.START_FEN);
        keys.clear();
        keys.add(pos.key());
        synced = true;
    }

    public static boolean validBoard(char[] b, boolean whiteToMove) {
        int wk = 0, bk = 0;
        for (char p : b) {
            if (p == 'K') wk++;
            else if (p == 'k') bk++;
        }
        if (wk != 1 || bk != 1) return false;
        for (int i = 0; i < 8; i++) {
            if (b[i] == 'P' || b[i] == 'p' || b[56 + i] == 'P' || b[56 + i] == 'p') return false;
        }
        return !Rules.kingInCheck(b, !whiteToMove);     // the side NOT to move can't be in check
    }

    private static Position guessPosition(char[] board, boolean whiteToMove) {
        StringBuilder castle = new StringBuilder();
        if (board[60] == 'K' && board[63] == 'R') castle.append('K');
        if (board[60] == 'K' && board[56] == 'R') castle.append('Q');
        if (board[4] == 'k' && board[7] == 'r') castle.append('k');
        if (board[4] == 'k' && board[0] == 'r') castle.append('q');
        return new Position(board.clone(), whiteToMove, castle.toString(), -1, 0, 1);
    }

    /** Would this reading be the current position, the start, or one/two moves from now? (no state change) */
    public boolean reachable(char[] board) {
        if (Arrays.equals(board, pos.b) || Arrays.equals(board, START_BOARD)) return true;
        for (int m : Rules.legalMoves(pos)) {
            Position p1 = Rules.apply(pos, m);
            if (Arrays.equals(p1.b, board)) return true;
            for (int m2 : Rules.legalMoves(p1)) {
                if (Arrays.equals(Rules.apply(p1, m2).b, board)) return true;
            }
        }
        return false;
    }

    /** After a guess (joined mid-game): use a "white"/"black" side-to-move hint when it is plausible. */
    public void applyTurnHint(String turn) {
        if (synced || turn == null) return;
        boolean white;
        if (turn.equals("white")) white = true;
        else if (turn.equals("black")) white = false;
        else return;
        if (white != pos.white && validBoard(pos.b, white)) {
            pos = new Position(pos.b.clone(), white, pos.castle, -1, 0, 1);
            keys.clear();
            keys.add(pos.key());
        }
    }

    /** @return "same", "move", "moves2", "resync" or "invalid" */
    public String update(char[] board) {
        if (Arrays.equals(board, pos.b)) return "same";
        if (Arrays.equals(board, START_BOARD)) {
            reset();
            return "resync";
        }
        int[] legal = Rules.legalMoves(pos);
        for (int m : legal) {
            Position p1 = Rules.apply(pos, m);
            if (Arrays.equals(p1.b, board)) {
                pos = p1;
                keys.add(p1.key());
                return "move";
            }
        }
        for (int m : legal) {                                  // missed one move in between?
            Position p1 = Rules.apply(pos, m);
            for (int m2 : Rules.legalMoves(p1)) {
                Position p2 = Rules.apply(p1, m2);
                if (Arrays.equals(p2.b, board)) {
                    pos = p2;
                    keys.add(p2.key());
                    return "moves2";
                }
            }
        }
        boolean turn = myWhite;
        if (!validBoard(board, turn)) {
            turn = !turn;
            if (!validBoard(board, turn)) return "invalid";
        }
        pos = guessPosition(board, turn);                      // joined mid-game / lost track
        keys.clear();
        keys.add(pos.key());
        synced = false;
        return "resync";
    }

    /** Treat the current position as "my turn" (used by the Suggest now button). */
    public void forceMyTurn() {
        if (pos.white != myWhite && validBoard(pos.b, myWhite)) {
            pos = new Position(pos.b.clone(), myWhite, pos.castle, -1, pos.half, pos.full);
        }
    }
}
