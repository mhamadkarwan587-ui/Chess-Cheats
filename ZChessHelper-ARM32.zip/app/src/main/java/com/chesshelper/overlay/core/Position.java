package com.chesshelper.overlay.core;

/** A chess position. Index 0 = a8, index 63 = h1; '.' = empty square. */
public final class Position {
    public final char[] b;
    public final boolean white;     // true = White to move
    public final String castle;     // subset of "KQkq"
    public final int ep;            // en-passant target square or -1
    public final int half;          // half-move clock (50-move rule)
    public final int full;

    public Position(char[] b, boolean white, String castle, int ep, int half, int full) {
        this.b = b;
        this.white = white;
        this.castle = castle;
        this.ep = ep;
        this.half = half;
        this.full = full;
    }

    public static Position fromFen(String fen) {
        String[] parts = fen.trim().split("\\s+");
        char[] b = new char[64];
        int i = 0;
        for (char ch : parts[0].toCharArray()) {
            if (ch == '/') continue;
            if (ch >= '1' && ch <= '8') {
                for (int k = 0; k < ch - '0'; k++) b[i++] = '.';
            } else {
                b[i++] = ch;
            }
        }
        boolean white = parts[1].equals("w");
        String castle = parts[2].equals("-") ? "" : parts[2];
        int ep = parts[3].equals("-") ? -1 : Rules.nameSq(parts[3]);
        int half = parts.length > 4 ? Integer.parseInt(parts[4]) : 0;
        int full = parts.length > 5 ? Integer.parseInt(parts[5]) : 1;
        return new Position(b, white, castle, ep, half, full);
    }

    public String key() {
        return new String(b) + (white ? 'w' : 'b') + castle + ep;
    }
}
