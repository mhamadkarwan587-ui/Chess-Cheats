package com.chesshelper.overlay.core;

/** A move packed into an int: from | to << 6 | promotion << 12. Squares: 0 = a8 ... 63 = h1. */
public final class Move {
    private Move() {
    }

    public static int make(int from, int to, char promo) {
        int p = promo == 'Q' ? 1 : promo == 'R' ? 2 : promo == 'B' ? 3 : promo == 'N' ? 4 : 0;
        return from | (to << 6) | (p << 12);
    }

    public static int from(int m) {
        return m & 63;
    }

    public static int to(int m) {
        return (m >> 6) & 63;
    }

    /** 'Q','R','B','N' or 0 when the move is not a promotion. */
    public static char promo(int m) {
        switch ((m >> 12) & 7) {
            case 1:
                return 'Q';
            case 2:
                return 'R';
            case 3:
                return 'B';
            case 4:
                return 'N';
            default:
                return 0;
        }
    }
}
