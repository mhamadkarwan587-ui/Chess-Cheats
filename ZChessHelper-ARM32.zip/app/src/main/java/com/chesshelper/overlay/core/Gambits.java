package com.chesshelper.overlay.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * A small opening book of gambits (pawn sacrifices for activity), best-rated first. Lines are written as
 * from-to squares ("e2e4"). A line is followed by position, so transpositions work too.
 */
public final class Gambits {
    private Gambits() {
    }

    private static int counter;

    public static final class Line {
        public final String name;
        public final boolean forWhite;
        public final String[] moves;
        public final int id;
        String[] keys;                  // position key before each move (filled on first use)
        int[] ints;                     // the moves as move ints

        public Line(String name, boolean forWhite, String moves) {
            this.name = name;
            this.forWhite = forWhite;
            this.moves = moves.trim().split("\\s+");
            synchronized (Gambits.class) {
                this.id = counter++;
            }
        }

        /** Unique text for this line (used to remember that it failed). */
        public String key() {
            return name + "#" + id;
        }

        public boolean isTrap() {
            return name.contains("Trap") || name.contains("Mate");
        }

        synchronized void prepare() {
            if (keys != null) return;
            String[] k = new String[moves.length];
            int[] mi = new int[moves.length];
            int n = 0;
            Position p = Position.fromFen(Rules.START_FEN);
            for (String t : moves) {
                int m = parse(p, t);
                if (m < 0) break;
                k[n] = p.key();
                mi[n] = m;
                n++;
                p = Rules.apply(p, m);
            }
            ints = java.util.Arrays.copyOf(mi, n);
            keys = java.util.Arrays.copyOf(k, n);
        }
    }

    public static final class Pick {
        public final Line line;
        public final int move;

        Pick(Line line, int move) {
            this.line = line;
            this.move = move;
        }
    }

    /** What the opponent seems to be playing. */
    public static final class Detected {
        public String names;
        public boolean trap;
    }

    /**
     * Does the opponent's play so far follow a known gambit or trap (their moves only; ours are ignored, so it
     * keeps working after we have deviated from the line)? Only reported when it is specific enough: at least three
     * opponent moves, and at most three opening families fit.
     *
     * @param history all moves of the game so far, from the start position
     * @return null when nothing specific is recognised
     */
    public static Detected detectOpponent(int[] history, boolean myWhite, Line[] book) {
        int k = history.length;
        if (k < 1 || (k % 2 == 0) != myWhite) return null;           // it must be our turn
        int first = myWhite ? 1 : 0;                                 // index of the opponent's first move
        int oppMoves = (k - first + 1) / 2;
        if (oppMoves < 3) return null;                               // too early to say anything specific
        List<Line> hits = new ArrayList<>();
        for (Line line : book) {
            if (line.forWhite == myWhite) continue;                  // only lines played by the side we face
            line.prepare();
            int len = line.ints.length;
            if (len < k - 1 || len < first + 1) continue;
            boolean ok = true;
            for (int j = first; j < k; j += 2) {
                if (j >= len || history[j] != line.ints[j]) {
                    ok = false;
                    break;
                }
            }
            if (ok) hits.add(line);
        }
        if (hits.isEmpty()) return null;
        List<String> families = new ArrayList<>();
        List<Line> reps = new ArrayList<>();
        for (Line l : hits) {
            String f = family(l.name);
            if (!families.contains(f)) {
                families.add(f);
                reps.add(l);
            }
        }
        if (families.size() > 3) return null;                        // not specific enough: stay quiet
        Detected d = new Detected();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < reps.size() && i < 2; i++) {
            if (i > 0) sb.append(" / ");
            sb.append(families.get(i));
        }
        for (Line l : hits) if (l.isTrap()) d.trap = true;
        d.names = sb.toString();
        return d;
    }

    /** "Custom Gambit: Evans Gambit Lasker Line" -> "Evans Gambit". */
    static String family(String name) {
        int c = name.indexOf(": ");
        if (c >= 0 && name.startsWith("Custom")) name = name.substring(c + 2);
        String[] w = name.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < w.length && i < 2; i++) {
            if (w[i].startsWith("(")) break;
            if (i > 0) sb.append(' ');
            sb.append(w[i]);
        }
        return sb.toString();
    }

    private static final Line[] CURATED = {
            // ---- for White
            new Line("Queen's Gambit Declined", true, "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3"),
            new Line("Queen's Gambit Accepted", true, "d2d4 d7d5 c2c4 d5c4 g1f3 g8f6 e2e3 e7e6 f1c4 c7c5"),
            new Line("Queen's Gambit vs Slav", true, "d2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 d5c4 a2a4 c8f5"),
            new Line("Evans Gambit", true, "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4a5 d2d4 e5d4 e1g1"),
            new Line("Scotch Gambit", true, "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f1c4 g8f6 e4e5 d7d5 c4b5 f6e4 f3d4"),
            new Line("Smith-Morra Gambit", true, "e2e4 c7c5 d2d4 c5d4 c2c3 d4c3 b1c3 b8c6 g1f3 d7d6 f1c4 e7e6 e1g1"),
            new Line("Danish Gambit", true, "e2e4 e7e5 d2d4 e5d4 c2c3 d4c3 f1c4 c3b2 c1b2"),
            new Line("Danish Gambit declined", true, "e2e4 e7e5 d2d4 e5d4 c2c3 d7d5 e4d5 d8d5 c3d4"),
            new Line("Vienna Gambit", true, "e2e4 e7e5 b1c3 g8f6 f2f4 d7d5 f4e5 f6e4 g1f3 f8e7"),
            new Line("King's Gambit Accepted", true, "e2e4 e7e5 f2f4 e5f4 g1f3 g7g5 h2h4 g5g4 f3e5"),
            new Line("King's Gambit Declined", true, "e2e4 e7e5 f2f4 f8c5 g1f3 d7d6 c2c3 g8f6"),
            new Line("Blackmar-Diemer Gambit", true, "d2d4 d7d5 e2e4 d5e4 b1c3 g8f6 f2f3 e4f3 g1f3"),
            // ---- for Black
            new Line("Albin Countergambit", false, "d2d4 d7d5 c2c4 e7e5 d4e5 d5d4 g1f3 b8c6"),
            new Line("Budapest Gambit", false, "d2d4 g8f6 c2c4 e7e5 d4e5 f6g4 c1f4 b8c6 g1f3 f8b4 b1d2 d8e7"),
            new Line("Benko Gambit", false, "d2d4 g8f6 c2c4 c7c5 d4d5 b7b5 c4b5 a7a6 b5a6 c8a6 b1c3 g7g6"),
            new Line("Falkbeer Countergambit", false, "e2e4 e7e5 f2f4 d7d5 e4d5 e5e4 d2d3 g8f6 b1c3"),
            new Line("Schliemann Gambit", false, "e2e4 e7e5 g1f3 b8c6 f1b5 f7f5 b1c3 f5e4 c3e4 d7d5"),
            new Line("Traxler Counterattack", false, "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 f8c5"),
            new Line("Latvian Gambit", false, "e2e4 e7e5 g1f3 f7f5 f3e5 d8f6 d2d4 d7d6 e5c4 f5e4 b1c3 f6g6"),
    };

    /** Best first: the hand-picked sound gambits, then the traps and the rest of the Wikipedia list. */
    public static final Line[] BOOK = build();

    private static Line[] build() {
        java.util.List<Line> all = new ArrayList<>(java.util.Arrays.asList(CURATED));
        for (String s : BookData.LINES) {
            String[] p = s.split("\\|");
            all.add(new Line(p[0], p[1].equals("W"), p[2]));
        }
        return all.toArray(new Line[0]);
    }

    /** The move int for "e2e4"-style text in this position, or -1 if it is not legal. */
    public static int parse(Position pos, String text) {
        if (text.length() < 4) return -1;
        int from = Rules.nameSq(text.substring(0, 2)), to = Rules.nameSq(text.substring(2, 4));
        char want = text.length() > 4 ? Character.toUpperCase(text.charAt(4)) : 'Q';
        int found = -1;
        for (int m : Rules.legalMoves(pos)) {
            if (Move.from(m) == from && Move.to(m) == to
                    && (Move.promo(m) == 0 || Character.toUpperCase((char) Move.promo(m)) == want)) found = m;
        }
        return found;
    }

    /**
     * All book moves that fit the position (best-rated line first). A line fits when the current position
     * is reached somewhere in it by playing its moves from the start, it is our turn, and the line
     * has a next move for us.
     */
    public static List<Pick> matches(Position pos, boolean myWhite, Set<String> failed, Line[] book) {
        List<Pick> out = new ArrayList<>();
        if (pos.white != myWhite) return out;
        String key = pos.key();
        for (Line line : book) {
            if (line.forWhite != myWhite || (failed != null && failed.contains(line.key()))) continue;
            line.prepare();
            for (int i = 0; i < line.ints.length; i++) {
                if (line.keys[i].equals(key)) {
                    int m = line.ints[i];
                    boolean dup = false;
                    for (Pick o : out) if (o.move == m) dup = true;
                    if (!dup) out.add(new Pick(line, m));
                    break;
                }
            }
        }
        return out;
    }
}
