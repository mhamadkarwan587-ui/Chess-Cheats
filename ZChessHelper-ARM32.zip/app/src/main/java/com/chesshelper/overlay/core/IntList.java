package com.chesshelper.overlay.core;

import java.util.Arrays;

/** Tiny growable int list (avoids boxing inside the search). */
public final class IntList {
    public int[] a = new int[64];
    public int n;

    public void add(int v) {
        if (n == a.length) a = Arrays.copyOf(a, n * 2);
        a[n++] = v;
    }

    public void clear() {
        n = 0;
    }
}
