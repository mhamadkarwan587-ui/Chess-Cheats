package com.chesshelper.overlay.core;

/** Position -> FEN text. */
public final class Fen {
    private Fen() {
    }

    public static String of(Position p) {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < 8; r++) {
            int empty = 0;
            for (int c = 0; c < 8; c++) {
                char ch = p.b[r * 8 + c];
                if (ch == '.') {
                    empty++;
                } else {
                    if (empty > 0) sb.append(empty);
                    empty = 0;
                    sb.append(ch);
                }
            }
            if (empty > 0) sb.append(empty);
            if (r < 7) sb.append('/');
        }
        sb.append(p.white ? " w " : " b ");
        sb.append(p.castle.isEmpty() ? "-" : p.castle);
        sb.append(' ').append(p.ep >= 0 ? Rules.sqName(p.ep) : "-");
        sb.append(' ').append(p.half).append(' ').append(p.full);
        return sb.toString();
    }
}
